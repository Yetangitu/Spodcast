TYPE = 'type'
LIMIT = 'limit'
OFFSET = 'offset'
CREDENTIALS_PREFIX = 'spodcast-cred'
USER_READ_EMAIL = 'user-read-email'
FILE_EXISTS = -1
OPEN_SPOTIFY_URL = 'open.spotify.com'
IMAGE_CDN = lambda image_id_hex: f'https://i.scdn.co/image/{image_id_hex}'
